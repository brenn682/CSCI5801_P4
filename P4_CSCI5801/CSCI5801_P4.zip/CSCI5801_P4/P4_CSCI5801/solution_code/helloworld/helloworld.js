// the hello world program

document.write('Hello, World!');
alert("Hello, World!");
console.log('Hello, World!');  

