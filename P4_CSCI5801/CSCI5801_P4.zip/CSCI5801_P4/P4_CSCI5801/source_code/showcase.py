def foo(x):
    if isintance(x, list):
        print(x)
    else:
        print("need an int")
