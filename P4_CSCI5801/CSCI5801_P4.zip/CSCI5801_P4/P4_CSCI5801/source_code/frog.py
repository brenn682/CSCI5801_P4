def foo(x):
