    else:
        print("need an int")
